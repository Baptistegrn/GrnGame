<div align="center">
<img src="https://raw.githubusercontent.com/Baptistegrn/GrnGame/main/GrnGame/icone/iconex8.png" width="150" alt="GrnGame Icon">

<h1>GrnGame</h1>

[![PyPI](https://img.shields.io/badge/pypi-v1.0.0-orange.svg)](https://pypi.org/project/GrnGame/)
[![Python Version](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Contributions Welcome](https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat)](https://github.com/Baptistegrn/GrnGame/issues)

[ **Français** | [English](#english-version) ]

</div>

**GrnGame** est un moteur de jeu 2D performant pour Python, conçu spécifiquement pour le pixel art.

**PyPi pas encore mis à jour 2.0.0**

Avec une gestion optimisée des sprites (batch rendering) et une API intuitive inspirée de pyxel et pygame, vous pouvez créer des jeux fluides et légers facilement.

<div align="center">
<img src="https://raw.githubusercontent.com/Baptistegrn/GrnGame/main/GrnGame/creations/example/example.gif" width="45%">
<img src="https://raw.githubusercontent.com/Baptistegrn/GrnGame/main/GrnGame/creations/spaceattacks/space.gif" width="35%">
<img src="https://raw.githubusercontent.com/Baptistegrn/GrnGame/main/GrnGame/creations/examplebis/platformer.gif" width="35%">
</div>

## Spécifications

- Fonctionne sur Windows et Linux
- Programmation en Python 3.8+
- Rendu optimisé avec Batch Rendering
- Audio multicanal (32 canaux simultanés)
- Entrées complètes (Clavier, Souris, Manettes)
- Support des polices personnalisées (Bitmap fonts)
- Physique 2D intégrée (Platformer)
- Compilation facile en exécutable

## Installation

### Via PyPI

```bash
pip install GrnGame
```

### Depuis les sources

Si votre système nécessite une compilation native (ex: Linux spécifique), GrnGame utilisera automatiquement `xmake`.

```bash
# 1. Installe xmake si nécessaire
GrnGame_xmake

# 2. Relancez votre terminal, puis lancez votre script
python main.py
```

## Utilisation Rapide

Dans votre script Python, importez `GrnGame`, définissez une fonction `update`, et initialisez le moteur.

```python
import GrnGame

def update():
    # Dessiner un sprite
    GrnGame.image.dessiner("./assets/player.png", 10, 10, 32, 32)
    
    # Entrées clavier (Noms des touches anglaises: 'space', 'enter', etc.)
    if GrnGame.clavier.juste_presse("space"):
        GrnGame.son.jouer("./assets/jump.wav")
        
    # Quitter
    if GrnGame.clavier.juste_presse("escape"):
        GrnGame.utils.stopper_jeu()

# Initialiser le jeu
GrnGame.utils.init(
    largeur=160,              # Résolution virtuelle
    hauteur=90,               # Résolution virtuelle
    fps=60,                   # Images par seconde cible
    coeff=4,                  # Échelle de la fenêtre
    chemin_image="./assets",  # Dossier racine des images
    chemin_son="./assets",    # Dossier racine des sons
    update_func=update,       # Fonction de boucle
    nom_fenetre="Mon Jeu",
    chemin_erreur="erreurs/err.log" # Chemin vers les logs d'erreurs
)
```

## Référence API

### Système & Constantes (`GrnGame.const`, `GrnGame.utils`)

#### Constantes

- `largeur`, `hauteur`  
  La largeur et la hauteur de la résolution virtuelle.

- `dt`  
  Le temps écoulé entre deux frames (Delta Time).

- `fps`  
  Le nombre d'images par seconde actuel.

- `time`  
  Le nombre total de frames écoulées depuis le démarrage.

- `souris_x`, `souris_y`  
  Position de la souris relative à l'écran virtuel.

- `mouse_presse`  
  Renvoie `True` si le bouton gauche de la souris est enfoncé.

- `mouse_juste_presse`  
  Renvoie `True` si le bouton gauche de la souris vient d'être pressé ce frame.

- `mouse_droit_presse`  
  Renvoie `True` si le bouton droit de la souris est enfoncé.

- `mouse_droit_juste_presse`  
  Renvoie `True` si le bouton droit de la souris vient d'être pressé ce frame.

- `decalage_x`, `decalage_y`  
  Le décalage actuel de la caméra (coordonnées du coin supérieur gauche).

- `en_marche`  
  Renvoie `True` si le jeu est en cours d'exécution.

#### Utilitaires

- `init(largeur, hauteur, fps, coeff, chemin_image, chemin_son, bande_noir, update_func, nom_fenetre, chemin_erreur)`  
  Initialise la fenêtre et le moteur.

- `stopper_jeu()`  
  Ferme proprement le moteur et la fenêtre.

- `redimensionner_fenetre()`  
  Bascule entre le mode fenêtré et le plein écran.

- `colorier(r, g, b)`  
  Applique une teinte de couleur RGB à tous les rendus suivants.

- `ecrire_log(type_erreur, message)`  
  Écrit un message dans les fichiers de logs. Types disponibles : `"info"`, `"debug"`, `"avertissement"`, `"erreur"`.

- `changer_log(niveau)`  
  Change le niveau de journalisation. Niveaux disponibles : `"info"`, `"debug"`, `"avertissement"`, `"erreur"`.

- `platformer_2d(dt, pos_x, pos_y, vitesse_y, en_air, larg_joueur, haut_joueur, blocs, [gravite], [force_saut], [vitesse_max_chute], [correction_mur], [activer_saut])`  
  Physique 2D intégrée pour les jeux de plateforme. Gère la gravité, les sauts, et les collisions avec les blocs. Renvoie un tuple `(nouvelle_pos_x, nouvelle_pos_y, nouvelle_vitesse_y, nouveau_en_air)`.
  - `dt` : Delta time (utiliser `GrnGame.const.dt`)
  - `pos_x`, `pos_y` : Position actuelle du joueur
  - `vitesse_y` : Vitesse verticale actuelle
  - `en_air` : `True` si le joueur est en l'air
  - `larg_joueur`, `haut_joueur` : Dimensions du joueur
  - `blocs` : Liste de rectangles `[(x, y, w, h), ...]` représentant les collisions
  - `gravite` : Force de gravité (défaut: 400.0)
  - `force_saut` : Force du saut, valeur négative (défaut: -200.0)
  - `vitesse_max_chute` : Vitesse maximale de chute (défaut: 500.0)
  - `correction_mur` : Distance de correction lors d'une collision murale (défaut: 100.0)
  - `activer_saut` : `True` pour effectuer un saut ce frame

### Graphismes (`GrnGame.image`)

- `dessiner(lien, x, y, w, h, [sens], [rotation], [transparence])`  
  Dessine une image à la position donnée. `sens` permet d'inverser l'image (0=normal, 1=miroir horizontal).

- `dessiner_batch(ids, xs, ys, ws, hs, [sens], [rotations], [transparence])`  
  Dessine une liste d'images en un seul appel GPU pour des performances maximales.

- `dessiner_forme(x, y, w, h, [sens], [rotation], [transparence], [r], [g], [b])`  
  Dessine un rectangle coloré (uni ou avec transparence).

- `dessiner_forme_batch(xs, ys, ws, hs, [sens], [rotations], [transparences], [rs], [gs], [bs])`  
  Dessine une liste de rectangles colorés en un seul appel GPU.

- `dessiner_mot(lien_police, mot, x, y, coeff, ecart, [sens], [rotation], [alpha])`  
  Affiche du texte en utilisant une police bitmap (dossier d'images PNG).
  - `lien_police` : Chemin vers le dossier contenant les caractères (ex: `"./fonts/ma_police/"`)
  - `mot` : Texte à afficher
  - `x`, `y` : Position du texte
  - `coeff` : Échelle du texte
  - `ecart` : Espacement entre les caractères
  - `sens` : Inversion horizontale (0=normal, 1=miroir)
  - `rotation` : Rotation en degrés
  - `alpha` : Transparence (0-255)

- `charger_toutes_les_textures(dossier)`  
  Précharge toutes les images d'un dossier en mémoire pour de meilleures performances.

- `charger_tous_les_sons(dossier)`  
  Précharge tous les sons d'un dossier en mémoire.

- `liberer_gestionnaire_image()`  
  Libère toutes les textures chargées de la mémoire.

- `liberer_gestionnaire_son()`  
  Libère tous les sons chargés de la mémoire.

### Audio (`GrnGame.son`)

- `jouer(lien, [boucle], [canal], [volume])`  
  Joue un son `.wav`. 
  - `boucle` : Nombre de répétitions (-1 pour infini, 0 pour une seule lecture)
  - `canal` : Canal audio (0-31, ou -1 pour choix automatique)
  - `volume` : Volume de lecture (0-128, défaut: 64)

- `arreter(lien)`  
  Arrête la lecture d'un son spécifique.

- `arreter_canal(canal)`  
  Stoppe tous les sons sur un canal spécifique (0-31).

- `pause(lien)`  
  Met en pause un son spécifique.

- `pause_canal(canal)`  
  Met en pause tous les sons sur un canal spécifique.

- `reprendre(lien)`  
  Reprend la lecture d'un son mis en pause.

- `reprendre_canal(canal)`  
  Reprend la lecture de tous les sons mis en pause sur un canal spécifique.

### Entrées (`GrnGame.clavier`, `GrnGame.manette`)

#### Clavier

- `juste_presse(touche)`  
  Renvoie `True` si la touche vient d'être pressée ce frame. (Ex: "space", "a", "up")

- `enfoncee(touche)`  
  Renvoie `True` tant que la touche est maintenue.

<details>
<summary><b>Liste complète des touches supportées</b></summary>

**Lettres** : `a` à `z`

**Chiffres** : `0` à `9`

**Navigation** :
- Flèches : `up`, `down` (ou `dn`), `left` (ou `lt`), `right` (ou `rt`)
- Page : `home`, `end`, `pageup` (ou `pgup`), `pagedown` (ou `pgdn`)

**Système** :
- `space`, `enter` (ou `return`), `tab`, `backspace`
- `escape` (ou `esc`), `delete`, `insert`

**Modificateurs** :
- Shift : `shift`, `lshift`, `rshift`
- Ctrl : `ctrl` (ou `control`), `lctrl`, `rctrl`
- Alt : `alt`, `lalt`, `ralt`
- Caps : `caps`, `capslock`
- `numlock`, `scrolllock`

**Touches fonction** : `f1` à `f12`

**Spéciales** :
- `pause`, `break`, `print` (ou `prtscr`, `printscreen`)
- `sysreq`, `menu`, `application`

**GUI/Système** :
- Windows : `lwin`, `rwin`, `lgui`, `rgui`
- Super : `lsuper`, `rsuper`
- Mac : `lcmd`, `rcmd`

**Pavé numérique** :
- Chiffres : `kp0` à `kp9`
- Opérateurs : `kp+` (ou `kpplus`), `kp-` (ou `kpminus`), `kp*` (ou `kpmultiply`), `kp/` (ou `kpdivide`)
- Autres : `kp=` (ou `kpequals`), `kp.` (ou `kpperiod`), `kpenter` (ou `kpe`)

**Média** :
- Volume : `mute` (ou `audiomute`), `volumeup` (ou `volup`, `audioup`), `volumedown` (ou `voldown`, `audiodown`)
- Contrôle : `play` (ou `audioplay`, `mediaplay`, `playpause`), `stop` (ou `audiostop`, `mediastop`)
- Navigation : `next` (ou `audionext`, `medianext`), `previous` (ou `prev`, `audioprev`, `mediaprev`)

**Navigateur** :
- `browserback`, `browserfwd`, `browserstop`
- `browserhome`, `browserrefresh`, `browsersearch`

**Énergie** : `power`, `sleep`

**Caractères spéciaux** : `-`, `=`, `[`, `]`, `;`, `'`, `,`, `.`, `/`, `` ` ``, `\`

</details>

#### Manette

- `init([index])`  
  Initialise la manette. `index` spécifie quelle manette utiliser (0 pour la première, défaut: 0).

- `enfoncee(bouton)`  
  Renvoie `True` si le bouton de la manette est maintenu. (Ex: "a", "b", "start")

- `juste_presse(bouton)`  
  Renvoie `True` si le bouton de la manette vient d'être pressé ce frame.

- `renvoie_joysticks([dead_zone])`  
  Renvoie les axes des sticks et gâchettes sous forme de liste `[lx, ly, rx, ry, lt, rt]`.
  - Valeurs entre -1.0 et 1.0 pour les sticks
  - Valeurs entre 0.0 et 1.0 pour les gâchettes
  - `dead_zone` : Seuil pour ignorer les petites déviations (défaut: 0.1)

- `fermer()`  
  Ferme la connexion avec la manette.

<details>
<summary><b>Boutons de manette supportés</b></summary>

**Boutons faciaux** : `a`, `b`, `x`, `y`

**Système** : `start`, `back`, `select`, `guide`, `home`, `share`

**Bumpers** : `lb`, `rb`, `l1`, `r1`

**Sticks cliquables** : `l3`, `r3`

**D-Pad** : `up`, `down`, `left`, `right`

**Additionnels** : `paddle1`, `paddle2`, `paddle3`, `paddle4`, `touchpad`

**Valeurs des axes** :
- Retourne 6 valeurs flottantes entre -1.0 et 1.0
- `dead_zone` : seuil pour ignorer les petites déviations (défaut: 0.1)
- Ordre : stick gauche X/Y, stick droit X/Y, gâchette gauche, gâchette droite

</details>

## Compilation

Pour créer un exécutable autonome de votre jeu :

```bash
# Créer un exécutable (Windows .exe ou Linux binaire)
GrnGame_app mon_jeu.py --noconsole --icon mon_icone.ico
```

L'exécutable sera généré dans le dossier courant.

## Licence

GrnGame est sous licence [MIT License](LICENSE).

---

# English Version

**GrnGame** is a high-performance 2D game engine for Python, specifically designed for pixel art.

**PyPi not yet updated to 2.0.0**

With optimized sprite management (batch rendering) and an intuitive API inspired by pyxel and pygame, you can easily create smooth and lightweight games.

## Specifications

- Works on Windows and Linux
- Programming in Python 3.8+
- Optimized rendering with Batch Rendering
- Multi-channel audio (32 simultaneous channels)
- Complete inputs (Keyboard, Mouse, Gamepads)
- Custom font support (Bitmap fonts)
- Integrated 2D physics (Platformer)
- Easy compilation to executable

## Installation

### Via PyPI

```bash
pip install GrnGame
```

### From Sources

If your system requires native compilation (e.g., specific Linux), GrnGame will automatically use `xmake`.

```bash
# 1. Install xmake if necessary
GrnGame_xmake

# 2. Restart your terminal, then run your script
python main.py
```

## Quick Start

In your Python script, import `GrnGame`, define an `update` function, and initialize the engine.

```python
import GrnGame

def update():
    # Draw a sprite
    GrnGame.image.draw("./assets/player.png", 10, 10, 32, 32)
    
    # Keyboard inputs
    if GrnGame.clavier.just_pressed("space"):
        GrnGame.son.play("./assets/jump.wav")
        
    # Quit
    if GrnGame.clavier.just_pressed("escape"):
        GrnGame.utils.stop_game()

# Initialize the game
GrnGame.utils.initialize(
    width=160,               # Virtual resolution
    height=90,               # Virtual resolution
    fps=60,                  # Target frames per second
    scale=4,                 # Window scale
    image_path="./assets",   # Root folder for images
    sound_path="./assets",   # Root folder for sounds
    update_func=update,      # Loop function
    window_name="My Game",
    error_path="errors/err.log" # Path to error logs
)
```

## API Reference

### System & Constants (`GrnGame.const`, `GrnGame.utils`)

#### Constants

- `width`, `height`  
  The width and height of the virtual resolution.

- `dt`  
  Time elapsed between two frames (Delta Time).

- `fps`  
  Current frames per second.

- `time`  
  Total number of frames elapsed since startup.

- `mouse_x`, `mouse_y`  
  Mouse position relative to virtual screen.

- `mouse_pressed`  
  Returns `True` if left mouse button is pressed.

- `mouse_just_pressed`  
  Returns `True` if left mouse button was just pressed this frame.

- `mouse_right_pressed`  
  Returns `True` if right mouse button is pressed.

- `mouse_right_just_pressed`  
  Returns `True` if right mouse button was just pressed this frame.

- `offset_x`, `offset_y`  
  Current camera offset (top-left corner coordinates).

- `running`  
  Returns `True` if the game is running.

#### Utilities

- `initialize(width, height, fps, scale, image_path, sound_path, letterbox, update_func, window_name, error_path)`  
  Initialize the window and engine.

- `stop_game()`  
  Properly close the engine and window.

- `resize_window()`  
  Toggle between windowed and fullscreen mode.

- `colorize(r, g, b)`  
  Apply an RGB color tint to all subsequent renders.

- `write_log(type_error, message)`  
  Write a message to log files. Available types: `"info"`, `"debug"`, `"avertissement"`, `"erreur"`.

- `change_log(level)`  
  Change the logging level. Available levels: `"info"`, `"debug"`, `"avertissement"`, `"erreur"`.

- `platformer_2d(dt, pos_x, pos_y, vitesse_y, en_air, larg_joueur, haut_joueur, blocs, [gravite], [force_saut], [vitesse_max_chute], [correction_mur], [activer_saut])`  
  Integrated 2D physics for platform games. Handles gravity, jumps, and block collisions. Returns tuple `(new_pos_x, new_pos_y, new_vitesse_y, new_en_air)`.
  - `dt` : Delta time (use `GrnGame.const.dt`)
  - `pos_x`, `pos_y` : Current player position
  - `vitesse_y` : Current vertical velocity
  - `en_air` : `True` if player is airborne
  - `larg_joueur`, `haut_joueur` : Player dimensions
  - `blocs` : List of rectangles `[(x, y, w, h), ...]` representing collisions
  - `gravite` : Gravity force (default: 400.0)
  - `force_saut` : Jump force, negative value (default: -200.0)
  - `vitesse_max_chute` : Maximum fall speed (default: 500.0)
  - `correction_mur` : Wall collision correction distance (default: 100.0)
  - `activer_saut` : `True` to perform a jump this frame

### Graphics (`GrnGame.image`)

- `draw(path, x, y, w, h, [direction], [rotation], [transparency])`  
  Draw an image at given position. `direction` allows flipping (0=normal, 1=horizontal mirror).

- `draw_batch(ids, xs, ys, ws, hs, [directions], [rotations], [transparency])`  
  Draw a list of images in a single GPU call for maximum performance.

- `draw_shape(x, y, w, h, [direction], [rotation], [transparency], [r], [g], [b])`  
  Draw a colored rectangle (solid or with transparency).

- `draw_shape_batch(xs, ys, ws, hs, [directions], [rotations], [transparencies], [rs], [gs], [bs])`  
  Draw a list of colored rectangles in a single GPU call.

- `draw_word(font_path, word, x, y, scale, spacing, [direction], [rotation], [alpha])`  
  Display text using bitmap font (folder of PNG images).
  - `font_path` : Path to folder containing characters (e.g., `"./fonts/my_font/"`)
  - `word` : Text to display
  - `x`, `y` : Text position
  - `scale` : Text scale
  - `spacing` : Character spacing
  - `direction` : Horizontal flip (0=normal, 1=mirror)
  - `rotation` : Rotation in degrees
  - `alpha` : Transparency (0-255)

- `load_all_textures(folder)`  
  Preload all images from a folder into memory for better performance.

- `load_all_sounds(folder)`  
  Preload all sounds from a folder into memory.

- `free_image_manager()`  
  Free all loaded textures from memory.

- `free_sound_manager()`  
  Free all loaded sounds from memory.

### Audio (`GrnGame.son`)

- `play(path, [loop], [channel], [volume])`  
  Play a `.wav` sound. 
  - `loop` : Number of repetitions (-1 for infinite, 0 for single playback)
  - `channel` : Audio channel (0-31, or -1 for automatic choice)
  - `volume` : Playback volume (0-128, default: 64)

- `stop(path)`  
  Stop playback of a specific sound.

- `stop_channel(channel)`  
  Stop all sounds on a specific channel (0-31).

- `pause_sound(path)`  
  Pause a specific sound.

- `pause_channel(channel)`  
  Pause all sounds on a specific channel.

- `resume(path)`  
  Resume playback of a paused sound.

- `resume_channel(channel)`  
  Resume playback of all paused sounds on a specific channel.

### Inputs (`GrnGame.clavier`, `GrnGame.manette`)

#### Keyboard

- `just_pressed(key)`  
  Returns `True` if key was just pressed this frame. (Ex: "space", "a", "up")

- `pressed(key)`  
  Returns `True` while key is held down.

#### Gamepad

- `initialize([index])`  
  Initialize gamepad. `index` specifies which gamepad to use (0 for first, default: 0).

- `pressed(button)`  
  Returns `True` if gamepad button is held down. (Ex: "a", "b", "start")

- `just_pressed(button)`  
  Returns `True` if gamepad button was just pressed this frame.

- `get_joysticks([dead_zone])`  
  Returns stick axes and triggers as list `[lx, ly, rx, ry, lt, rt]`.
  - Values between -1.0 and 1.0 for sticks
  - Values between 0.0 and 1.0 for triggers
  - `dead_zone` : Threshold to ignore small deviations (default: 0.1)

- `close()`  
  Close gamepad connection.

## Compilation

To create a standalone executable of your game:

```bash
# Create executable (Windows .exe or Linux binary)
GrnGame_app my_game.py --noconsole --icon my_icon.ico
```

The executable will be generated in the current folder.

## License

GrnGame is licensed under the [MIT License](LICENSE).

<div align="center">
Developed by Baptiste GUERIN
</div>
