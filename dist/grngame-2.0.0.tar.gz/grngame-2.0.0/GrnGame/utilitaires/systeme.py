from platform import system

def renvoie_systeme():
    return system().lower()
