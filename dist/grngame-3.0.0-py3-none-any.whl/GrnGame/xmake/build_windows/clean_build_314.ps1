
Remove-Item -Recurse -Force "$env:LOCALAPPDATA\.xmake" -ErrorAction SilentlyContinue;

Remove-Item -Recurse -Force .xmake, build -ErrorAction SilentlyContinue;

$env:PATH = "C:\Users\bapti\AppData\Local\Programs\Python\Python314;" + $env:PATH;
Write-Host "Version Python active :" -ForegroundColor Green;
python --version;

xmake f -c -y;
xmake -y