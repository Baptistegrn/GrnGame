import GrnGame

camera_x = 0.0
camera_y = 0.0
grille = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1],
    [1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
]

def dessiner_grille():
    taille_bloc = 16.0
    
    for y in range(len(grille)):
        for x in range(len(grille[y])):
            if grille[y][x] == 1:
                bloc_x = x * taille_bloc
                bloc_y = y * taille_bloc
                ecran_x = bloc_x - camera_x
                ecran_y = bloc_y - camera_y
                
                GrnGame.image.dessiner_forme(
                    x=ecran_x,
                    y=ecran_y,
                    w=taille_bloc,
                    h=taille_bloc,
                    sens=0,
                    rotation=0,
                    transparence=255,
                    r=80,
                    g=80,
                    b=80
                )
            
                GrnGame.image.dessiner_forme(x=ecran_x, y=ecran_y, w=taille_bloc, h=1.0, sens=0, rotation=0, transparence=255, r=120, g=120, b=120)
                GrnGame.image.dessiner_forme(x=ecran_x, y=ecran_y, w=1.0, h=taille_bloc, sens=0, rotation=0, transparence=255, r=120, g=120, b=120)
                GrnGame.image.dessiner_forme(x=ecran_x, y=ecran_y + taille_bloc - 1.0, w=taille_bloc, h=1.0, sens=0, rotation=0, transparence=255, r=40, g=40, b=40)
                GrnGame.image.dessiner_forme(x=ecran_x + taille_bloc - 1.0, y=ecran_y, w=1.0, h=taille_bloc, sens=0, rotation=0, transparence=255, r=40, g=40, b=40)

def update():
    global camera_x, camera_y
    
    vitesse_camera = 50.0
    GrnGame.utils.colorier(200,20,90)
    if GrnGame.clav.enfoncee("d"):
        camera_x += vitesse_camera * GrnGame.const.dt
    if GrnGame.clav.enfoncee("q"):
        camera_x -= vitesse_camera * GrnGame.const.dt
    if GrnGame.clav.enfoncee("z"):
        camera_y -= vitesse_camera * GrnGame.const.dt
    if GrnGame.clav.enfoncee("s"):
        camera_y += vitesse_camera * GrnGame.const.dt
    
    if GrnGame.clav.juste_presser("f4"):
        GrnGame.utils.redimensionner_fenetre()
    
    dessiner_grille()
    
    GrnGame.image.dessiner_forme(
        x=80.0 - 2.0,
        y=80.0 - 2.0,
        w=4.0,
        h=4.0,
        sens=0,
        rotation=0,
        transparence=255,
        r=255,
        g=0,
        b=0
    )

GrnGame.utils.init(
    largeur=160,
    hauteur=160,
    fps=128,
    coeff=3,
    chemin_image="./coucou",
    chemin_son="./coucou",
    bande_noir=True,
    update_func=update,
    nom_fenetre="Test Grille 16x16",
    chemin_erreur="erreurs.log"
)